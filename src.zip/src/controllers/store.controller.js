const storeRepository = require('../repositories/store.repository');
const baseResponse = require('../utils/baseResponse.util');

exports.getAllStores = async (req, res) => {
    try {
        const stores = await storeRepository.getAllStores();
        baseResponse(res, true, 200, "Stores retrieved successfully", stores);
    } catch (error) {
        baseResponse(res, false, 500, "Error retrieving stores", error);
    }
};

exports.createStore = async (req, res) => {
    const { name, address } = req.body;

    if (!name || !address) {
        return baseResponse(res, false, 400, "Missing store name or address", null);
    }

    try {
        const store = await storeRepository.createStore(req.body);
        baseResponse(res, true, 201, "Store created successfully", store);
    } catch (error) {
        if (error.message.includes("duplicate key")) {
            return baseResponse(res, false, 409, "Store already exists", null);
        }
        baseResponse(res, false, 500, error.message || "Server Error", error);
    }
};

exports.getStorebyID = async (req, res) => {
    try {
        const store = await storeRepository.getStoresbyID(req.params.id);
        if (store) {
            baseResponse(res, true, 200, "Store found", store);
        } else {
            baseResponse(res, false, 404, "Store not found", null);
        }
    } catch (error) {
        baseResponse(res, false, 500, error.message || "Server Error", error);
    }
};

exports.updateStore = async (req, res) => {
    const { id, name, address } = req.body;

    if (!id) {
        return baseResponse(res, false, 400, "Missing store ID", null);
    }

    try {
        const store = await storeRepository.updateStore(req.body);
        if (store) {
            baseResponse(res, true, 200, "Store updated successfully", store);
        } else {
            baseResponse(res, false, 404, "Store not found", null);
        }
    } catch (error) {
        baseResponse(res, false, 500, error.message || "Server Error", error);
    }
};

exports.deleteStore = async (req, res) => {
    try {
        const store = await storeRepository.deleteStore(req.params.id);
        if (store) {
            baseResponse(res, true, 200, "Store deleted successfully", store);
        } else {
            baseResponse(res, false, 404, "Store not found", null);
        }
    } catch (error) {
        baseResponse(res, false, 500, error.message || "Server Error", error);
    }
};

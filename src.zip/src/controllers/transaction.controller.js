const transactionRepository = require('../repositories/transaction.repository');
const baseResponse = require('../utils/baseResponse.util');

exports.createTransaction = async (req, res) => {
    const { item_id, quantity, user_id } = req.body;

    if (!item_id || quantity === undefined || quantity === null || !user_id) {
        return baseResponse(res, false, 400, "Missing item_id, quantity, or user_id", null);
    }

    const numQuantity = parseInt(quantity);
    if (numQuantity <= 0) {
        return baseResponse(res, false, 400, "Quantity must be larger than 0", null);
    }

    try {
        const transaction = await transactionRepository.createTransaction({ item_id, quantity, user_id });
        baseResponse(res, true, 201, "Transaction created", transaction);
    } catch (error) {
        baseResponse(res, false, 500, error.message || "Server Error", error);
    }
};

exports.payTransaction = async (req, res) => {
    try {
        const transaction = await transactionRepository.payTransaction(req.params.id);

        if (transaction.error) {
            if (transaction.error.includes("not found")) {
                return baseResponse(res, false, 404, transaction.error, null); 
            } 
            if (transaction.error.includes("insufficient")) {
                return baseResponse(res, false, 409, transaction.error, null); // Gunakan 409 untuk stok atau saldo tidak mencukupi
            }
            return baseResponse(res, false, 500, transaction.error, null); 
        }

        baseResponse(res, true, 200, "Payment successful", transaction);
    } catch (error) {
        console.error("Error in controller:", error);
        baseResponse(res, false, 500, "Server Error", null);
    }
};

exports.deleteTransaction = async (req, res) => {
    try {
        const transaction = await transactionRepository.deleteTransactionById(req.params.id);
        if(transaction) {
            baseResponse(res, true, 200, "Transaction deleted", transaction);
        } else {
            baseResponse(res, false, 404, "Transaction not found", null);
        }
    } catch (error) {
        baseResponse(res, false, 500, error.message || "Server Error", null);
    }
};

exports.getTransaction = async (req, res) => {
    try {
        const transaction = await transactionRepository.getTransaction();
        if (transaction.length == 0){
            baseResponse(res, true, 200, "Transactions not found", null);
        } else {
            baseResponse(res, true, 200, "Transactions found", transaction)
        }
    } catch (error) {
        baseResponse(res, false, 500, error.message || "Server Error", null);   
    }
}